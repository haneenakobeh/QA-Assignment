package najah.test;

import static org.junit.jupiter.api.Assertions.*;

import najah.code.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;

public class ProductTest {
    Product p;

	@BeforeEach
	void setUp() throws Exception {
		p = new Product("Book",100.0);
		System.out.println("Product setup complete");
	}

	@Test
	void test() {
		p.applyDiscount(20);
		assertEquals(80.0, p.getFinalPrice(), 0.001, "The final price of product should be 80.0" );

	}

	@Test
	@DisplayName("Valid discount application")
	void testApplyDiscount() {
		p.applyDiscount(10);
		assertAll("Discounted price",
				() -> assertEquals(90.0,p.getFinalPrice(), 0.001),
				() -> assertEquals(10.0,p.getDiscount(), 0.001)
		);

	}


	@Test
	@DisplayName("Invalid discount - above 50")
	void testInvalidDiscountHigh(){
		assertThrows(IllegalArgumentException.class, () -> p.applyDiscount(60));
	}


	@Test
	@DisplayName("Invalid discount - negative")
	void testInvalidDiscountLow(){
		assertThrows(IllegalArgumentException.class, () -> p.applyDiscount(-5));
	}


	@ParameterizedTest
	@ValueSource(doubles = {0, 25, 50})
	@DisplayName("Parameterized test for discount values")
	void testValidDiscounts(double discount){
		p.applyDiscount(discount);
		assertTrue(p.getFinalPrice() <= p.getPrice());
	}


	@Test
	@DisplayName("Timeout test")
	@Timeout(value = 500, unit = TimeUnit.MILLISECONDS)
	void timeoutTest(){
		p.getFinalPrice();
	}
}
