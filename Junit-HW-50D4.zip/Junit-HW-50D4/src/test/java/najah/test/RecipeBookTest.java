package najah.test;

import najah.code.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RecipeBook Tests")
public class RecipeBookTest {

    RecipeBook book;
    Recipe recipe;


    @BeforeEach
    void setUp() throws Exception {
        book = new RecipeBook();
        recipe = new Recipe();
        recipe.setName("Coffee");
        recipe.setPrice("10");
        recipe.setAmtCoffee("2");
        recipe.setAmtMilk("1");
        recipe.setAmtSugar("1");
        recipe.setAmtChocolate("0");
    }

    @Test
    @DisplayName("Add valid recipe")
    void testAddRecipe() {
        boolean added = book.addRecipe(recipe);
        assertTrue(added);
    }

    @Test
    @DisplayName("Add duplicate recipe")
    void testDuplicateRecipe() {
        book.addRecipe(recipe);
        assertFalse(book.addRecipe(recipe));
    }

    @Test
    @DisplayName("Delete recipe by index")
    void testDeleteRecipe() {
        book.addRecipe(recipe);
        String name = book.deleteRecipe(0);
        assertEquals("Coffee", name);
    }

    @Test
    @DisplayName("Edit recipe at index")
    void testEditRecipe() throws Exception {
        book.addRecipe(recipe);
        Recipe newRecipe = new Recipe();
        newRecipe.setName("Latte");
        newRecipe.setPrice("15");
        newRecipe.setAmtCoffee("3");
        newRecipe.setAmtMilk("2");
        newRecipe.setAmtSugar("1");
        newRecipe.setAmtChocolate("1");
        String result = book.editRecipe(0, newRecipe);
        assertEquals("Coffee", result);
    }

    @ParameterizedTest
    @ValueSource(strings = {"Tea", "Latte", "Espresso"})
    @DisplayName("Test adding recipes with different names")
    void testAddRecipeWithDifferentNames(String name) {
        recipe.setName(name);
        boolean added = book.addRecipe(recipe);
        assertTrue(added, "Recipe with name " + name + " should be added successfully");
    }

    @Test
    @DisplayName("Timeout test")
    @Timeout(value = 500, unit = TimeUnit.MILLISECONDS) // Set timeout to 500 milliseconds
    void timeoutTest() {
        book.addRecipe(recipe);
    }
}
